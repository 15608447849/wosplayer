/**
 * Created by Administrator on 2017/2/28.
 */
var changePageFeq = 10; //页面切换速度，单位为秒
var changeDataFeq = 45; // 更新数据频率，单位为秒
window.onload = function () {
    function creatRem(){
        //设置rem大小
        var W = document.documentElement.clientWidth;            //获取对应设备的可视宽度
        //alert(W);
        var perRem = W / 19.2;                 //6.4的来源：根据设计图,若设计尺寸为640，则分为6.4等分，1rem=100px（若为1280，则为12.8）.不分为640或是64份的原因是chrome下最小字体为12，若设置HTML的字体最小为5px,则浏览器计算出来的还是 12px
        //alert(perRem);
        document.documentElement.style.fontSize = perRem + 'px';
    }
    creatRem();
    window.onresize=function(){
        creatRem();
        //console.log("...");
    }
}

var app = angular.module('httpApp', ['ngAnimate']);

app.controller('httpController', ['$scope', '$http','$timeout', '$interval', function ($scope, $http,$timeout,$interval) {
    $scope.now = new Date();
    var timer_time = $interval(function () {
        $scope.now = new Date();
    }, 1000);

    $scope.getData=function(){
        $http.get("resource.xml?"+(new Date()).getTime(),
            {
                transformResponse: function (cnv) {
                    var x2js = new X2JS();
                    var aftCnv = x2js.xml_str2json(cnv);
                    return aftCnv;
                }
            })
            .success(function (response) {
                console.log("get data....");
                $scope.data = response;
            });
    }
    $scope.getData();

    var timer_getData = $interval(function () {
        $scope.getData();
    }, changeDataFeq*1000);
    $scope.show="deposit1";
    var show_params = ["deposit1", "deposit2", "deposit3", "loan1", "loan2", "loan3", "waihui1", "waihui2"];
    var count = 1;
    $interval(function(){
        count = count % 8;
        $scope.show=show_params[count];
        console.log("change page ....");
        count ++;
    },changePageFeq*1000)
}]).filter("timeFormat",function(){
    return function(input,param1) {
        var chosenDate=new Date(input);
        var yyyy=chosenDate.getFullYear();
        var MM=chosenDate.getMonth()+1;
        var dd=chosenDate.getDate();
        var HH =chosenDate.getHours()>9?chosenDate.getHours():"0"+chosenDate.getHours();
        var mm=chosenDate.getMinutes()>9?chosenDate.getMinutes():"0"+chosenDate.getMinutes();
        var ss=chosenDate.getSeconds()>9?chosenDate.getSeconds():"0"+chosenDate.getSeconds();
        var day=chosenDate.getDay();
        var dayMap={0:"周日",1:"周一",2:"周二",3:"周三",4:"周四",5:"周五",6:"周六"}
        switch (param1) {
            case "yyyy-mm-dd":
                var new_input = yyyy+"年"+ MM+"月"+dd+"日  "+dayMap[day];
                break;
            case "HH":
                var new_input=HH;
                break;
            case "mm":
                var new_input=mm;
                break;
            default :return input;
        }
        return new_input;
    }
});